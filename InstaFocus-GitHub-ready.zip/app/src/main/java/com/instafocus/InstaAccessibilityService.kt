package com.instafocus

import android.accessibilityservice.AccessibilityService
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class InstaAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("settings", MODE_PRIVATE) }
    private val windows = mutableListOf<WindowManager.LayoutParams>()
    private val views = mutableListOf<BlockView>()
    private var lastInstagram = false
    private var mode = Mode.NONE
    private var searchHasQuery = false
    private var previousMode = Mode.NONE
    private var allowSharedViewer = false

    private enum class Mode { NONE, HOME, REELS, SEARCH, MESSAGES, OTHER }

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = serviceInfo.apply {
            flags = flags or android.accessibilityservice.AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        }
        refresh()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.packageName?.toString() != INSTAGRAM) {
            if (lastInstagram) clearOverlays()
            lastInstagram = false
            return
        }
        lastInstagram = true
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ refresh() }, 80)
    }

    override fun onInterrupt() = Unit

    private fun refresh() {
        if (!lastInstagram) return
        val root = rootInActiveWindow
        val state = detectMode(root)
        if (state.first != Mode.NONE) {
            val detected = state.first
            if (previousMode == Mode.MESSAGES && detected == Mode.REELS) allowSharedViewer = true
            if (detected == Mode.MESSAGES || detected == Mode.HOME || detected == Mode.SEARCH) allowSharedViewer = false
            previousMode = detected
            mode = detected
        }
        searchHasQuery = state.second
        val shouldBlock = when (mode) {
            Mode.HOME -> prefs.getBoolean("home", true)
            Mode.REELS -> prefs.getBoolean("reels", true) && !allowSharedViewer
            Mode.SEARCH -> prefs.getBoolean("search", true) && !searchHasQuery
            else -> false
        }
        val quote = mode == Mode.SEARCH && prefs.getBoolean("quote", true) && !searchHasQuery
        if (shouldBlock || quote) showOverlays() else clearOverlays()
    }

    private fun detectMode(root: AccessibilityNodeInfo?): Pair<Mode, Boolean> {
        if (root == null) return Mode.NONE to false
        val nodes = ArrayList<AccessibilityNodeInfo>(300)
        collect(root, nodes, 0)
        var reels = false
        var search = false
        var home = false
        var messages = false
        var query = false
        for (n in nodes) {
            val raw = n.text?.toString() ?: ""
            val cd = n.contentDescription?.toString() ?: ""
            val text = "$raw $cd".lowercase()
            if (text.trim() == "reels" || (text.contains("reels") && n.isSelected)) reels = true
            if (text == "search" || text.contains("search and explore") || text.contains("search tab")) search = true
            if (text == "home" || text.contains("home tab")) home = true
            if (text.contains("messages") || text.contains("direct")) messages = true
            if (n.isEditable && raw.isNotBlank()) query = true
        }
        val result = when {
            reels && isLikelyReels(nodes) -> Mode.REELS
            search && isLikelySearch(nodes) -> Mode.SEARCH
            messages && isLikelyMessages(nodes) -> Mode.MESSAGES
            home -> Mode.HOME
            else -> Mode.NONE
        }
        return result to query
    }

    private fun isLikelyReels(nodes: List<AccessibilityNodeInfo>) = nodes.count {
        val t = ((it.text?.toString() ?: "") + " " + (it.contentDescription?.toString() ?: "")).lowercase()
        t.contains("reels") || t.contains("likes") || t.contains("comments") || t.contains("audio")
    } >= 2

    private fun isLikelySearch(nodes: List<AccessibilityNodeInfo>) = nodes.any {
        val t = ((it.text?.toString() ?: "") + " " + (it.contentDescription?.toString() ?: "")).lowercase()
        t.contains("search") && (it.isFocused || it.isEditable)
    } || nodes.count { (it.text?.toString() ?: "").lowercase().contains("for you") } > 0

    private fun isLikelyMessages(nodes: List<AccessibilityNodeInfo>) = nodes.count {
        val t = ((it.text?.toString() ?: "") + " " + (it.contentDescription?.toString() ?: "")).lowercase()
        t.contains("message") || t.contains("chat")
    } >= 2

    private fun collect(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (depth > 18 || out.size > 350) return
        out.add(node)
        for (i in 0 until node.childCount) node.getChild(i)?.let { collect(it, out, depth + 1) }
    }

    private fun showOverlays() {
        clearOverlays()
        val w = resources.displayMetrics.widthPixels
        val h = resources.displayMetrics.heightPixels
        when (mode) {
            Mode.HOME -> if (prefs.getBoolean("home", true)) {
                // The upper ~24.5% remains interactive so Stories can be opened and watched.
                addBlock(0, (h * .245f).toInt(), w, (h * .91f).toInt(), "home-feed")
                // Block only the Reels navigation target; other bottom-nav targets remain usable.
                addBlock((w * .20f).toInt(), (h * .91f).toInt(), (w * .40f).toInt(), h, "reels-nav")
            }
            Mode.REELS -> if (prefs.getBoolean("reels", true) && !allowSharedViewer) {
                addBlock(0, 0, w, h, "reels-full")
            }
            Mode.SEARCH -> if (prefs.getBoolean("search", true) && !searchHasQuery) {
                // Covers the suggestion area only; the search field above remains interactive.
                addBlock(0, (h * .20f).toInt(), w, (h * .46f).toInt(), "search-suggestions", drawQuote = prefs.getBoolean("quote", true))
            }
            else -> Unit
        }
    }

    private fun addBlock(left: Int, top: Int, right: Int, bottom: Int, id: String, drawQuote: Boolean = false) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = BlockView(drawQuote)
        val p = WindowManager.LayoutParams(
            right - left,
            bottom - top,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            android.graphics.PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = left
            y = top
            title = "InstaFocus:$id"
        }
        try {
            wm.addView(view, p)
            views += view
            windows += p
        } catch (_: Exception) { }
    }

    private fun clearOverlays() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        views.forEach { try { wm.removeViewImmediate(it) } catch (_: Exception) {} }
        views.clear()
        windows.clear()
    }

    override fun onDestroy() {
        clearOverlays()
        super.onDestroy()
    }

    private inner class BlockView(private val drawQuote: Boolean) : View(this@InstaAccessibilityService) {
        private val quotePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var downX = 0f
        private var downY = 0f

        init {
            setBackgroundColor(currentSurface())
            isClickable = true
            isFocusable = false
            quotePaint.typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setOnTouchListener { _, _ -> true }
        }

        private fun currentSurface(): Int {
            val dark = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK == android.content.res.Configuration.UI_MODE_NIGHT_YES
            return if (dark) Color.rgb(13, 14, 17) else Color.WHITE
        }

        override fun onDraw(canvas: android.graphics.Canvas) {
            super.onDraw(canvas)
            if (!drawQuote) return
            val dark = resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK == android.content.res.Configuration.UI_MODE_NIGHT_YES
            val text = if (dark) Color.WHITE else Color.rgb(25, 25, 28)
            quotePaint.textAlign = Paint.Align.CENTER
            quotePaint.color = text
            quotePaint.textSize = (width * .052f).coerceIn(25f, 40f)
            val cx = width / 2f
            canvas.drawText("Protect your attention.", cx, height * .43f, quotePaint)
            quotePaint.textSize = (width * .036f).coerceIn(18f, 27f)
            canvas.drawText("Search with purpose, then leave.", cx, height * .58f, quotePaint)
            quotePaint.color = Color.rgb(131, 58, 180)
            quotePaint.textSize = (width * .033f).coerceIn(17f, 25f)
            canvas.drawText("InstaFocus", cx, height * .75f, quotePaint)
        }

        override fun onTouchEvent(event: MotionEvent): Boolean {
            if (currentModeIsReelsBlocked()) {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; return true }
                    MotionEvent.ACTION_UP -> {
                        val dx = event.rawX - downX
                        val dy = kotlin.math.abs(event.rawY - downY)
                        // A left-edge right-swipe acts like Back, so a blocked Reels screen can be exited
                        // without exposing the underlying Reel.
                        if (downX < 70f && dx > 110f && dy < 140f) performGlobalAction(GLOBAL_ACTION_BACK)
                        return true
                    }
                }
            }
            return true
        }

        private fun currentModeIsReelsBlocked(): Boolean = mode == Mode.REELS && !allowSharedViewer
    }

    companion object { private const val INSTAGRAM = "com.instagram.android" }
}
