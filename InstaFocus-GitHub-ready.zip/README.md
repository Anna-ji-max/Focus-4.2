# InstaFocus

Android accessibility overlay that lets the user keep selected Instagram areas usable while masking feed/reels/search suggestions according to the configured rules.

## GitHub Actions

Workflow: `.github/workflows/android.yml`

The repository root must contain `settings.gradle.kts` and `app/` directly. Do not upload this project as an extra nested `instafocus/` folder.
